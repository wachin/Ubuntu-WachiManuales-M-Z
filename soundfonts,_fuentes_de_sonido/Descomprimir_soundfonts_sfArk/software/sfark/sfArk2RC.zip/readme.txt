sfArk v2.05 - May 29, 2000
--------------------------

A number of bug fixes since V2.04.  Our thanks to Jos� in Argentina for finding and reporting them:

1. Compressing an SF2 or SBK which had no audio samples at all (i.e. used only ROM samples) would crash the program. For example, it would happen with synthgm.sbk.  Fixed!

2. When uncomressing, .sbk files were wrongly named (with an .sf2 extension).  Fixed.

3. A few files (e.g. 8mbgmsfx.sf2) would fail to uncompress due to a small bug in the decompressor.  Fixed.

NB: The above #2 and #3 were in the decompressor only, so any files compressed with V2.04 are still ok.

4. Uncompressing files created with sfArk v1.1x was totally broken, although it appeared to work (Oops!).  Fixed.  This was actually a typo in the source rather than a "real" bug - it had been previously working, honest!  Sorry about that one.

5. Auto-delete was not actually deleting files in some cases - should now be working properly.



Still to be addressed (will probably wait until version 2.1)
* Help file to be added (help file from version 1.18 still applies for the most part).
* Auto upgrade of V1.18 .sfArk files to V2 (of course, this can be done manually by decompressing then recompressing).

Please email any comments/questions to: sfark@melodymachine.com

Please read the license agreement (license.txt)

sfArk SoundFont Compression is copyright, 1998-2000 MelodyMachine.com

