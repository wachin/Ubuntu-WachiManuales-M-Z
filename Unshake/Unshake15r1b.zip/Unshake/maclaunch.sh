#!/bin/sh
java -Xmx512m -jar Unshake.jar source/* &
