MetaStripper ver. 0.92
=======================

This utility will remove meta information (EXIF, COM and IPTC tags) 
from JPEG image files. You can automatically process a large number
of files with the click of a button. 

MetaStripper is very easy to use:

Simply select a folder containing the JPEG image files you want to
modify, set the options (which meta tags you want to remove), and
select where to save the modified files. You have two options:

Save to new folder
All files will be saved in the folder you've specified, using the original
filename(s). If the specified folder doesn't exist, it will be created 
automatically.

Select "Copy unprocessed files to target folder" to make sure that ALL 
files (including those that does not contain any Meta tags) are copied 
to the specified output folder.

Save using filename prefix
All files will be saved in the same folder as originally located, using the
filename prefix you've specified. For example, a modified image 
originally named filename.jpg will be saved as copy_filename.jpg

Note: This program will not, under any circumstance overwrite your 
original image files. The program will always assign a unique name 
to all modified files. If copy_filename.jpg exists, the program will name 
the new file as copy_filename_1.jpg, or copy_filename_2.jpg and so 
on.


LEGAL STUFF
This software is distributed as freeware, meaning you can use and
distribute it as you wish, provided that you do not charge anything
for doing so.

You are not allowed to distribute this program as part of a commercial 
product (including cover disks for magazines, etc.), without a prior 
written permisson by the author.


DISCLAIMER
THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT
WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY
OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR 
IMPLIED. NO WARRANTY OF FITNESS FOR A PARTICULAR 
PURPOSE IS OFFERED.


Copyright � 2002-2003 Jarle Aasland. All rights reserved.
Website: http://www.photothumb.com  
