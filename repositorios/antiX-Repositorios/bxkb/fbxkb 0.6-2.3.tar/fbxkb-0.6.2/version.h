#ifndef _VERSION_H
#define _VERSION_H


/* do not change this line - Makefile's 'tar' target depends on it */
#define VERSION "0.6.2"


#endif
