# -*- coding: utf-8 -*-
#
# PhotoFilmStrip - Creates movies out of your pictures.
#
# Copyright (C) 2014 Jens Goepfert
#

from photofilmstrip.core.GPlayer import GPlayer
AudioPlayer = GPlayer
