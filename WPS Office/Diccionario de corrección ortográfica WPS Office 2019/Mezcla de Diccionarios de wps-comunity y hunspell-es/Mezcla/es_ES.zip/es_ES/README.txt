
Cuando uno descarga el diccionario español España para WPS Office desde:

http://wps-community.org/download/dicts

no funciona para WPS Office 2019 por estar vacío el contenido de "main.dic"(que no tenía nada) por esta razón he añadido el contendido de "es_ES.dic" del paquete hunspell-es el cual es el diccionario de corrección ortofráfica español para LibreOffice desde los repositorios de Ubuntu

http://archive.ubuntu.com/ubuntu/pool/main/libr/libreoffice-dictionaries/hunspell-es_6.0.3-3_all.deb 

y al hacer esto si funciona
